# Democracy Simulator

A political simulation game.